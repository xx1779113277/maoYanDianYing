module.exports = {
    // mongoose数据库的连接码
    mongoURI: 'mongodb+srv://A:A@library-ckfti.azure.mongodb.net/douban?retryWrites=true&w=majority',
    tokenKey: 'DouBanDianYing'
}